﻿$(document).ready(function () {
    var sequence = $("#sequence").sequence({ nextButton: !0, prevButton: !0, pagination: !1, animateStartingFrameIn: !0, autoPlay: !1, autoPlayDelay: 2e3, preloader: !0, preloadTheseFrames: [1], navigationSkip: !1 });
});